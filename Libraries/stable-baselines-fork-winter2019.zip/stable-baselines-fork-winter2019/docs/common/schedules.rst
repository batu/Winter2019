.. _schedules:

Schedules
=========

Schedules are used as hyperparameter for most of the algortihms,
in order to change value of a parameter over time (usuallly the learning rate).


.. automodule:: stable_baselines.common.schedules
  :members:
